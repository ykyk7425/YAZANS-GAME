const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let niveau = 1;
let score = 0;
let gameOver = false;
let maxLevels = 500;
let player = { x: canvas.width / 2 - 15, y: canvas.height - 60, width: 30, height: 30, speed: 4, color: 'green' };
let playerBullets = [];
let enemies = [];
let enemyBullets = [];
let enemySpeed = 1.5;
let lastTime = Date.now();
let enemiesDestroyed = 0;

const keys = {};
canvas.addEventListener('click', shootBullet); // Mouse click to shoot

// Mouse position for aiming
let mouseX = canvas.width / 2;
let mouseY = canvas.height / 2;
canvas.addEventListener('mousemove', (e) => {
    mouseX = e.offsetX;
    mouseY = e.offsetY;
});

function createEnemies(count) {
    enemies = [];
    for (let i = 0; i < count; i++) {
        const enemy = {
            id: i, // Unique ID for each enemy
            x: Math.random() * (canvas.width - 30),
            y: -Math.random() * 150,
            width: 30,
            height: 30,
            color: 'red',
            lastShotTime: 0,
            shotsFired: 0, // Initialize shotsFired counter
        };
        enemies.push(enemy);
    }
    enemiesDestroyed = 0;  // Reset enemiesDestroyed count for the new level
}

function updatePlayer() {
    if (keys['ArrowLeft'] || keys['a']) player.x -= player.speed; // Move left
    if (keys['ArrowRight'] || keys['d']) player.x += player.speed; // Move right
    if (keys['ArrowUp'] || keys['w']) player.y -= player.speed; // Move up
    if (keys['ArrowDown'] || keys['s']) player.y += player.speed; // Move down
    player.x = Math.max(0, Math.min(canvas.width - player.width, player.x)); // Prevent out of bounds on left/right
    player.y = Math.max(0, Math.min(canvas.height - player.height, player.y)); // Prevent out of bounds on top/bottom
}

function shootBullet(event) {
    const angle = Math.atan2(mouseY - (player.y + player.height / 2), mouseX - (player.x + player.width / 2));
    const bullet = {
        x: player.x + player.width / 2 - 5,
        y: player.y + player.height / 2 - 10,
        width: 10,
        height: 20,
        color: 'darkred',
        speed: 6,
        vx: Math.cos(angle) * 6,
        vy: Math.sin(angle) * 6
    };
    playerBullets.push(bullet);
}

function updateBullets() {
    playerBullets = playerBullets.filter(b => b.y > 0 && b.x > 0 && b.x < canvas.width);
    playerBullets.forEach(b => {
        b.x += b.vx;
        b.y += b.vy;
    });
}

function updateEnemies() {
    const now = Date.now();
    enemies = enemies.filter(e => e.y < canvas.height);

    enemies.forEach((e, ei) => {
        e.y += enemySpeed;

        // Check for collisions with player bullets
        playerBullets.forEach((b, bi) => {
            if (b.x < e.x + e.width && b.x + b.width > e.x && b.y < e.y + e.height && b.y + b.height > e.y) {
                playerBullets.splice(bi, 1); // Remove bullet
                enemies.splice(ei, 1); // Remove enemy
                score += 10;
                enemiesDestroyed++; // Increment destroyed enemies count

                // Remove all bullets fired by this enemy
                enemyBullets = enemyBullets.filter(bullet => bullet.enemyId !== e.id);
            }
        });

        // If the enemy reaches the bottom, start new level
        if (e.y + e.height >= canvas.height) {
            niveau++;
            createEnemies(niveau);
        }

        // Make enemies shoot at the player
        if (e.shotsFired < 2 && now - e.lastShotTime > 1500) {
            const dx = player.x + player.width / 2 - (e.x + e.width / 2);
            const dy = player.y + player.height / 2 - (e.y + e.height);
            const length = Math.sqrt(dx * dx + dy * dy);
            enemyBullets.push({
                x: e.x + e.width / 2,
                y: e.y + e.height,
                width: 5,
                height: 10,
                dx: (dx / length) * 3,
                dy: (dy / length) * 3,
                enemyId: e.id // Associate this bullet with the enemy
            });
            e.lastShotTime = now;
            e.shotsFired++;
        }
    });

    // If all enemies are destroyed, proceed to the next level
    if (enemiesDestroyed === niveau) {
        niveau++;
        createEnemies(niveau);
    }
}

function updateEnemyBullets() {
    enemyBullets = enemyBullets.filter(b => b.y < canvas.height);
    enemyBullets.forEach((b, i) => {
        b.x += b.dx;
        b.y += b.dy;

        // Check for collision with player
        if (b.x < player.x + player.width && b.x + b.width > player.x && b.y < player.y + player.height && b.y + b.height > player.y) {
            endGame();
        }
    });
}

function drawPlayer() {
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.width, player.height);
}

function drawBullets() {
    playerBullets.forEach(b => {
        ctx.fillStyle = b.color;
        ctx.fillRect(b.x, b.y, b.width, b.height);
    });
}

function drawEnemies() {
    enemies.forEach(e => {
        ctx.fillStyle = e.color;
        ctx.fillRect(e.x, e.y, e.width, e.height);
    });
}

function drawEnemyBullets() {
    enemyBullets.forEach(b => {
        ctx.fillStyle = 'blue';
        ctx.fillRect(b.x, b.y, b.width, b.height);
    });
}

function drawHUD() {
    ctx.fillStyle = 'white';
    ctx.font = '16px Arial';
    ctx.fillText('Niveau: ' + niveau, 10, 20);
    ctx.fillText('Score: ' + score, 10, 40);
}

function drawGameOver() {
    ctx.fillStyle = 'white';
    ctx.font = '30px Arial';
    ctx.fillText('GAME OVER!', 300, canvas.height / 2);
    ctx.font = '16px Arial';
    ctx.fillText('Tryk Enter for at starte igen', 270, canvas.height / 2 + 40);
}

function endGame() {
    gameOver = true;
    document.getElementById('gameOverText').style.display = 'block'; // Show game over text
}

function restartGame() {
    niveau = 1;
    score = 0;
    gameOver = false;
    player.x = canvas.width / 2 - 15;
    player.y = canvas.height - 60;
    createEnemies(niveau);
    enemyBullets = [];
    document.getElementById('gameOverText').style.display = 'none'; // Hide game over text
    gameLoop();
}

document.addEventListener('keydown', (e) => {
    keys[e.key] = true;
    if (e.key === "Enter" && gameOver) {
        restartGame();
    }
});

document.addEventListener('keyup', (e) => {
    keys[e.key] = false;
});

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!gameOver) {
        updatePlayer();
        updateBullets();
        updateEnemies();
        updateEnemyBullets();
        drawPlayer();
        drawBullets();
        drawEnemies();
        drawEnemyBullets();
        drawHUD();
        requestAnimationFrame(gameLoop);
    } else {
        drawHUD();
        drawGameOver();
    }
}

createEnemies(niveau);
gameLoop();
